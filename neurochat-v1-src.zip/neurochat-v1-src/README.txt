╔══════════════════════════════════════════════════════╗
║          NeuroChat v3.0 — Инструкция                  ║
╚══════════════════════════════════════════════════════╝
cделано BY JEFFREYEPSTEIN & FAMALILY

БЫСТРЫЙ СТАРТ:
──────────────
1. Установи Node.js 18+ → https://nodejs.org/

2. Открой папку в терминале:
   cd neurochat-fixed

3. Установи зависимости:
   npm install

4. Создай файл .env из примера:
   Windows:   copy .env.example .env
   Mac/Linux: cp .env.example .env

5. Получи HF токен:
   → Зайди на https://huggingface.co/settings/tokens
   → Нажми "New token" → тип "Read" (или "Write")
   → Скопируй токен и вставь в .env в строку HF_TOKEN=

   ⚠ ВАЖНО — для router.huggingface.co нужен PRO токен!
     Если у тебя бесплатный аккаунт — приложение автоматически
     переключится на api-inference.huggingface.co (работает медленнее)

6. Запусти:
   node server.js

7. Открой в браузере:
   http://localhost:3000

════════════════════════════════════════════════════════

СТРУКТУРА ФАЙЛОВ:
─────────────────
neurochat-fixed/
├── server.js           — основной сервер Node.js (Express)
├── package.json        — зависимости
├── .env.example        — пример настроек
├── .env                — твои настройки (создай сам!)
├── public/
│   ├── index.html      — главная страница
│   ├── auth.html       — вход и регистрация
│   ├── chat.html       — главный чат с AI
│   ├── profile.html    — профиль пользователя
│   ├── pricing.html    — страница тарифов
│   ├── admin.html      — панель администратора
│   ├── style.css       — все стили
│   └── app.js          — общие утилиты (markdown, подсветка кода)
├── data/               — JSON-база данных (создаётся автоматически)
└── uploads/            — временные файлы фото (создаётся автоматически)

════════════════════════════════════════════════════════

cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY

cделано BY JEFFREYEPSTEIN & FAMALILYcделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILYcделано BY JEFFREYEPSTEIN & FAMALILY

cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY

cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY

cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY

cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY

cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
cделано BY JEFFREYEPSTEIN & FAMALILY
