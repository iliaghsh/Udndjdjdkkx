@echo off
title NeuroChat Server

if not exist "package.json" (
    echo ERROR: package.json not found.
    echo Please create package.json first or run 'npm init -y'
    pause
    exit /b 1
)

echo Checking dependencies...
if not exist "node_modules\" (
    echo Installing npm packages...
    call npm install
    if errorlevel 1 (
        echo npm install failed.
        pause
        exit /b 1
    )
    echo Dependencies installed.
) else (
    echo Dependencies already installed.
)

echo Starting NeuroChat server...
node server.js

pause