const TOKEN_KEY = "nc_token";
function getToken() { return localStorage.getItem(TOKEN_KEY); }
function setToken(t) { localStorage.setItem(TOKEN_KEY, t); }
function clearToken() { localStorage.removeItem(TOKEN_KEY); }

async function api(path, opts) {
  opts = opts || {};
  var headers = opts.headers || {};
  if (!opts.isForm) headers["Content-Type"] = "application/json";
  var tok = getToken();
  if (tok) headers["Authorization"] = "Bearer " + tok;
  var res = await fetch(path, Object.assign({}, opts, { headers: headers }));
  var ct = res.headers.get("content-type") || "";
  var data = ct.includes("json") ? await res.json() : await res.text();
  if (!res.ok) throw new Error((data && data.error) || "Ошибка запроса");
  return data;
}

async function requireAuth(redirect) {
  redirect = redirect || "/auth.html";
  if (!getToken()) { location.href = redirect; return null; }
  try { var d = await api("/api/me"); return d.user; }
  catch { clearToken(); location.href = redirect; return null; }
}

function escapeHtml(s) {
  if (!s && s !== 0) return "";
  return String(s).replace(/[&<>"']/g, function(c) {
    return { '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c];
  });
}

function initials(s) {
  if (!s) return "?";
  var parts = s.trim().split(/\s+/);
  if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
  return s.trim().slice(0, 2).toUpperCase();
}

// ===== Syntax highlighting =====
function highlight(code, lang) {
  var e = escapeHtml(code);
  var l = (lang || "").toLowerCase().trim();
  if (l === "python" || l === "py") return hlPython(e);
  if (l === "javascript" || l === "js") return hlJS(e);
  if (l === "typescript" || l === "ts") return hlTS(e);
  if (l === "java") return hlJava(e);
  if (l === "cpp" || l === "c++") return hlCpp(e);
  if (l === "c") return hlC(e);
  if (l === "csharp" || l === "c#" || l === "cs") return hlCsharp(e);
  if (l === "rust" || l === "rs") return hlRust(e);
  if (l === "go" || l === "golang") return hlGo(e);
  if (l === "html" || l === "xml") return hlHtml(e);
  if (l === "css" || l === "scss") return hlCss(e);
  if (l === "json") return hlJson(e);
  if (l === "bash" || l === "sh" || l === "shell") return hlBash(e);
  if (l === "sql") return hlSql(e);
  if (l === "yaml" || l === "yml") return hlYaml(e);
  return e;
}

var K = function(cls) { return function(m) { return '<span class="' + cls + '">' + m + '</span>'; }; };
function applyRules(c, rules) {
  var r = c;
  for (var i = 0; i < rules.length; i++) r = r.replace(rules[i][0], rules[i][1]);
  return r;
}

function hlPython(c) { return applyRules(c, [
  [/#[^\n]*/g, K("tok-cmt")],
  [/(&quot;|&#39;)((?:(?!\1)[\s\S])*?)\1/g, K("tok-str")],
  [/\b(def|class|import|from|return|if|elif|else|for|while|in|not|and|or|is|None|True|False|try|except|finally|with|as|pass|break|continue|raise|yield|lambda|global|nonlocal|del|assert|async|await)\b/g, K("tok-kw")],
  [/\b(print|len|range|type|str|int|float|list|dict|set|tuple|bool|input|open|enumerate|zip|map|filter|sorted|sum|min|max|abs|round|isinstance)\b/g, K("tok-builtin")],
  [/\bdef\s+([a-zA-Z_]\w*)/g, function(m,n){ return 'def <span class="tok-fn">' + n + '</span>'; }],
  [/\bclass\s+([A-Za-z_]\w*)/g, function(m,n){ return 'class <span class="tok-cls">' + n + '</span>'; }],
  [/\b(\d+\.?\d*)\b/g, K("tok-num")],
]); }

function hlJS(c) { return applyRules(c, [
  [/\/\/[^\n]*/g, K("tok-cmt")],
  [/\/\*[\s\S]*?\*\//g, K("tok-cmt")],
  [/(&quot;|&#39;|`)((?:(?!\1).)*)\1/g, K("tok-str")],
  [/\b(const|let|var|function|return|if|else|for|while|do|switch|case|break|continue|new|this|class|extends|import|export|default|from|async|await|try|catch|finally|throw|typeof|instanceof|in|of|null|undefined|void|static)\b/g, K("tok-kw")],
  [/\b(true|false)\b/g, K("tok-bool")],
  [/\b(console|document|window|Array|Object|String|Number|Boolean|Math|JSON|Promise|fetch)\b/g, K("tok-builtin")],
  [/([a-zA-Z_$]\w*)\s*(?=\()/g, function(m,n){ return '<span class="tok-fn">' + n + '</span>'; }],
  [/\b([A-Z][A-Za-z0-9_]*)\b/g, K("tok-cls")],
  [/\b(\d+\.?\d*)\b/g, K("tok-num")],
]); }

function hlTS(c) { return applyRules(c, [
  [/\/\/[^\n]*/g, K("tok-cmt")],
  [/\/\*[\s\S]*?\*\//g, K("tok-cmt")],
  [/(&quot;|&#39;|`)((?:(?!\1).)*)\1/g, K("tok-str")],
  [/\b(const|let|var|function|return|if|else|for|while|do|switch|case|break|continue|new|this|class|extends|import|export|default|from|async|await|try|catch|finally|throw|type|interface|enum|namespace|declare|abstract|implements|readonly|private|public|protected)\b/g, K("tok-kw")],
  [/\b(true|false|never|any|unknown|string|number|boolean)\b/g, K("tok-bool")],
  [/\b([A-Z][A-Za-z0-9_]*)\b/g, K("tok-cls")],
  [/([a-zA-Z_$]\w*)\s*(?=\()/g, function(m,n){ return '<span class="tok-fn">' + n + '</span>'; }],
  [/\b(\d+\.?\d*)\b/g, K("tok-num")],
]); }

function hlJava(c) { return applyRules(c, [
  [/\/\/[^\n]*/g, K("tok-cmt")],
  [/\/\*[\s\S]*?\*\//g, K("tok-cmt")],
  [/&quot;((?:[^&]|&(?!quot;))*?)&quot;/g, K("tok-str")],
  [/\b(public|private|protected|class|interface|enum|extends|implements|new|return|if|else|for|while|do|switch|case|break|continue|try|catch|finally|throw|static|final|void|abstract|import|package|this|super|null)\b/g, K("tok-kw")],
  [/\b(true|false)\b/g, K("tok-bool")],
  [/([a-zA-Z_]\w*)\s*(?=\()/g, function(m,n){ return '<span class="tok-fn">' + n + '</span>'; }],
  [/\b([A-Z][A-Za-z0-9_]*)\b/g, K("tok-cls")],
  [/\b(\d+\.?\d*)\b/g, K("tok-num")],
]); }

function hlCpp(c) { return applyRules(c, [
  [/\/\/[^\n]*/g, K("tok-cmt")],
  [/\/\*[\s\S]*?\*\//g, K("tok-cmt")],
  [/(#\s*(?:include|define|ifdef|ifndef|endif|pragma)[^\n]*)/g, K("tok-kw")],
  [/&quot;((?:[^&]|&(?!quot;))*?)&quot;/g, K("tok-str")],
  [/\b(int|long|short|char|float|double|bool|void|unsigned|const|static|return|if|else|for|while|do|switch|case|break|continue|class|struct|namespace|using|new|delete|nullptr|true|false|template|auto|try|catch|throw|virtual|override)\b/g, K("tok-kw")],
  [/([a-zA-Z_]\w*)\s*(?=\()/g, function(m,n){ return '<span class="tok-fn">' + n + '</span>'; }],
  [/\b(\d+\.?\d*)\b/g, K("tok-num")],
]); }

function hlC(c) { return applyRules(c, [
  [/\/\/[^\n]*/g, K("tok-cmt")],
  [/\/\*[\s\S]*?\*\//g, K("tok-cmt")],
  [/(#\s*(?:include|define|ifdef|ifndef|endif|pragma)[^\n]*)/g, K("tok-kw")],
  [/&quot;((?:[^&]|&(?!quot;))*?)&quot;/g, K("tok-str")],
  [/\b(int|long|short|char|float|double|void|unsigned|const|static|return|if|else|for|while|do|switch|case|break|continue|struct|union|enum|typedef|extern|NULL|sizeof)\b/g, K("tok-kw")],
  [/([a-zA-Z_]\w*)\s*(?=\()/g, function(m,n){ return '<span class="tok-fn">' + n + '</span>'; }],
  [/\b(\d+\.?\d*)\b/g, K("tok-num")],
]); }

function hlCsharp(c) { return applyRules(c, [
  [/\/\/[^\n]*/g, K("tok-cmt")],
  [/\/\*[\s\S]*?\*\//g, K("tok-cmt")],
  [/&quot;((?:[^&]|&(?!quot;))*?)&quot;/g, K("tok-str")],
  [/\b(public|private|protected|internal|class|interface|enum|struct|abstract|sealed|static|override|virtual|new|return|if|else|for|foreach|while|do|switch|case|break|continue|try|catch|finally|throw|using|namespace|this|base|null|void|async|await|var|readonly|const)\b/g, K("tok-kw")],
  [/\b(true|false)\b/g, K("tok-bool")],
  [/([a-zA-Z_]\w*)\s*(?=\()/g, function(m,n){ return '<span class="tok-fn">' + n + '</span>'; }],
  [/\b([A-Z][A-Za-z0-9_]*)\b/g, K("tok-cls")],
  [/\b(\d+\.?\d*)\b/g, K("tok-num")],
]); }

function hlRust(c) { return applyRules(c, [
  [/\/\/[^\n]*/g, K("tok-cmt")],
  [/\/\*[\s\S]*?\*\//g, K("tok-cmt")],
  [/&quot;((?:[^&]|&(?!quot;))*?)&quot;/g, K("tok-str")],
  [/\b(fn|let|mut|use|pub|mod|struct|enum|impl|trait|for|while|if|else|match|return|break|continue|in|ref|move|self|super|where|type|const|static|async|await|unsafe|loop)\b/g, K("tok-kw")],
  [/\b(true|false|None|Some|Ok|Err)\b/g, K("tok-bool")],
  [/([a-zA-Z_]\w*)\s*(?=\(|!)/g, function(m,n){ return '<span class="tok-fn">' + n + '</span>'; }],
  [/\b(\d+\.?\d*)\b/g, K("tok-num")],
]); }

function hlGo(c) { return applyRules(c, [
  [/\/\/[^\n]*/g, K("tok-cmt")],
  [/\/\*[\s\S]*?\*\//g, K("tok-cmt")],
  [/&quot;((?:[^&]|&(?!quot;))*?)&quot;/g, K("tok-str")],
  [/\b(func|var|const|type|struct|interface|map|chan|go|defer|for|range|if|else|switch|return|break|continue|goto|package|import|nil|make|new|len|cap|append|error)\b/g, K("tok-kw")],
  [/\b(true|false)\b/g, K("tok-bool")],
  [/([a-zA-Z_]\w*)\s*(?=\()/g, function(m,n){ return '<span class="tok-fn">' + n + '</span>'; }],
  [/\b([A-Z][A-Za-z0-9_]*)\b/g, K("tok-cls")],
  [/\b(\d+\.?\d*)\b/g, K("tok-num")],
]); }

function hlHtml(c) { return applyRules(c, [
  [/&lt;!--[\s\S]*?--&gt;/g, K("tok-cmt")],
  [/(&lt;\/?)([\w-]+)/g, function(m,b,t){ return '<span class="tok-kw">' + b + '</span><span class="tok-fn">' + t + '</span>'; }],
  [/([\w-]+)=(&quot;[^"]*&quot;)/g, function(m,a,v){ return '<span class="tok-cls">' + a + '</span>=<span class="tok-str">' + v + '</span>'; }],
  [/(&gt;)/g, K("tok-kw")],
]); }

function hlCss(c) { return applyRules(c, [
  [/\/\*[\s\S]*?\*\//g, K("tok-cmt")],
  [/(#[0-9a-fA-F]{3,8})\b/g, K("tok-str")],
  [/([a-zA-Z-]+)\s*:/g, function(m,p){ return '<span class="tok-cls">' + p + '</span>:'; }],
  [/\b(\d+\.?\d*)(px|em|rem|%|vh|vw|s|ms|deg)\b/g, function(m,n,u){ return '<span class="tok-num">' + n + '</span>' + u; }],
]); }

function hlJson(c) { return applyRules(c, [
  [/&quot;((?:[^&]|&(?!quot;))*?)&quot;\s*:/g, K("tok-cls")],
  [/:\s*&quot;((?:[^&]|&(?!quot;))*?)&quot;/g, function(m){ return ': <span class="tok-str">' + m.slice(2) + '</span>'; }],
  [/\b(true|false|null)\b/g, K("tok-bool")],
  [/\b(\d+\.?\d*)\b/g, K("tok-num")],
]); }

function hlBash(c) { return applyRules(c, [
  [/#[^\n]*/g, K("tok-cmt")],
  [/&quot;((?:[^&]|&(?!quot;))*?)&quot;/g, K("tok-str")],
  [/\b(if|then|else|elif|fi|for|do|done|while|case|esac|in|function|return|echo|exit|export|source|local)\b/g, K("tok-kw")],
  [/(\$\{?[\w@#*?!$-]+\}?)/g, K("tok-fn")],
  [/\b(\d+)\b/g, K("tok-num")],
]); }

function hlSql(c) { return applyRules(c, [
  [/--[^\n]*/g, K("tok-cmt")],
  [/'((?:[^'])*?)'/g, K("tok-str")],
  [/\b(SELECT|FROM|WHERE|INSERT|INTO|VALUES|UPDATE|SET|DELETE|CREATE|TABLE|DROP|ALTER|JOIN|LEFT|RIGHT|INNER|ON|AS|AND|OR|NOT|NULL|ORDER|BY|GROUP|HAVING|LIMIT|COUNT|SUM|AVG|MAX|MIN|DISTINCT)\b/gi, function(m){ return '<span class="tok-kw">' + m.toUpperCase() + '</span>'; }],
  [/\b(\d+\.?\d*)\b/g, K("tok-num")],
]); }

function hlYaml(c) { return applyRules(c, [
  [/#[^\n]*/g, K("tok-cmt")],
  [/^([\s]*)([\w-]+)\s*:/gm, function(m,sp,k){ return sp + '<span class="tok-cls">' + k + '</span>:'; }],
  [/\b(true|false|null|yes|no)\b/g, K("tok-bool")],
  [/\b(\d+\.?\d*)\b/g, K("tok-num")],
]); }

// ===== Markdown to HTML =====
function mdToHtml(md) {
  if (!md) return "";
  var html = String(md);
  html = html.replace(/!\[([^\]]*)\]\((data:[^)]{1,500000}|https?:[^)]+)\)/g,
    function(_, alt, src) { return '<img alt="' + escapeHtml(alt) + '" src="' + src + '" loading="lazy"/>'; });
  html = html.replace(/```(\w*)\n?([\s\S]*?)```/g, function(_, lang, code) {
    var clean = code.replace(/^\n|\n$/g, "");
    var hl = highlight(clean, lang);
    var label = lang || "code";
    var id = "cb" + Math.random().toString(36).slice(2, 9);
    return '<div class="code-block"><div class="code-header"><span class="code-lang">' + escapeHtml(label) + '</span>'
      + '<button class="copy-btn" onclick="copyCode(\'' + id + '\',this)">'
      + '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>'
      + ' Копировать</button></div><pre><code id="' + id + '">' + hl + '</code></pre></div>';
  });
  html = html.replace(/`([^`\n]+)`/g, function(_, c) { return '<code>' + escapeHtml(c) + '</code>'; });
  html = html.replace(/\*\*\*([^*]+)\*\*\*/g, "<strong><em>$1</em></strong>");
  html = html.replace(/\*\*([^*\n]+)\*\*/g, "<strong>$1</strong>");
  html = html.replace(/__([^_\n]+)__/g, "<strong>$1</strong>");
  html = html.replace(/\*([^*\n]+)\*/g, "<em>$1</em>");
  html = html.replace(/^### (.+)$/gm, "<h3>$1</h3>");
  html = html.replace(/^## (.+)$/gm, "<h2>$1</h2>");
  html = html.replace(/^# (.+)$/gm, "<h1>$1</h1>");
  html = html.replace(/^> (.+)$/gm, "<blockquote>$1</blockquote>");
  html = html.replace(/^---$/gm, "<hr>");
  html = html.replace(/\[([^\]]+)\]\((https?[^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  html = html.replace(/^[\-\*\+] (.+)$/gm, "<li>$1</li>");
  html = html.replace(/(<li>.*<\/li>\n?)+/g, function(m) { return "<ul>" + m + "</ul>"; });
  html = html.replace(/^\d+\. (.+)$/gm, "<li>$1</li>");
  html = html.split(/\n{2,}/).map(function(p) {
    p = p.trim();
    if (!p) return "";
    if (/^<(h\d|ul|ol|pre|div|hr|blockquote|img)/.test(p)) return p;
    return "<p>" + p.replace(/\n/g, "<br>") + "</p>";
  }).filter(Boolean).join("\n");
  return html;
}

// ===== Typewriter animation =====
function typewriterAnimate(el, html, onDone) {
  var hasComplexContent = html.includes('code-block') || html.includes('<img');
  if (hasComplexContent) {
    el.innerHTML = html;
    el.classList.add('stream-done');
    if (onDone) onDone();
    return;
  }
  el.innerHTML = '';
  el.classList.add('streaming-text');
  var chars = html.split('');
  var i = 0;
  var buffer = '';
  var speed = Math.max(4, Math.min(18, Math.round(8000 / chars.length)));
  function step() {
    if (i >= chars.length) {
      el.innerHTML = html;
      el.classList.remove('streaming-text');
      el.classList.add('stream-done');
      if (onDone) onDone();
      return;
    }
    var chunk = Math.ceil(chars.length / 80);
    for (var j = 0; j < chunk && i < chars.length; j++, i++) buffer += chars[i];
    el.innerHTML = buffer + '<span class="type-cursor">▋</span>';
    requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

// ===== Copy code =====
function copyCode(id, btn) {
  var el = document.getElementById(id);
  if (!el) return;
  navigator.clipboard.writeText(el.innerText).then(function() {
    btn.innerHTML = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> Скопировано';
    btn.classList.add("copied");
    setTimeout(function() {
      btn.innerHTML = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg> Копировать';
      btn.classList.remove("copied");
    }, 2200);
  }).catch(function() {
    var ta = document.createElement('textarea');
    ta.value = el.innerText;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
  });
}
